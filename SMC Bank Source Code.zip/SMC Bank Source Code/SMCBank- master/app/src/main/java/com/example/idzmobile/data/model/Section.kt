package com.example.idzmobile.data.model


data class Section(
    val sectionTitle: String? = null,
    val sectionList: List<DataItemTransaction>? = null
)