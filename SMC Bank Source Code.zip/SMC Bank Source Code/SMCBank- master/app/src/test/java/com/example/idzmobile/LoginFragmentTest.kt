package com.example.idzmobile

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.idzmobile.ui.loginregister.login.LoginFragment
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LoginFragmentTest {
    @Test
    fun testLoginFragment(){
    
    }
}