package com.example.idzmobile.repositories

import com.example.idzmobile.data.DataRepository

class FakeRepositories {
}